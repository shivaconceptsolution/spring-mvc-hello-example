package com.scs.bao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.scs.dao.Additionbean;

@Controller
public class AdditionController {
	@RequestMapping("add")
    public ModelAndView additon(){
    	return new ModelAndView("addition","command",new Additionbean());
    }
	@RequestMapping(value="addlogic",method = RequestMethod.POST)
    public ModelAndView additonLogic(@ModelAttribute("Spring-MVC-Addition")Additionbean s){
		int a = s.getNum1();
		int b = s.getNum2();
		int c = a+b;
    	return new ModelAndView("additionresult","msg","Result is "+c);
    }
}
