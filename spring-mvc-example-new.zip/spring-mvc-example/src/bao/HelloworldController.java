package bao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloworldController {

	@RequestMapping("home")
	public ModelAndView homeAction()
	{
		return new ModelAndView("home");
	}
	@RequestMapping("addlogic")
	public ModelAndView homeAddLogic(HttpServletRequest request, HttpServletResponse response)
	{
		int a= Integer.parseInt(request.getParameter("txtnum1"));
		int b = Integer.parseInt(request.getParameter("txtnum2"));
		int c = a+b;
		return new ModelAndView("home","res","Result is "+c);
	}
	
}
